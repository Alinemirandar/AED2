package primeiroprojetoaednoite;

import java.util.Scanner;

public class PrimeiroProjetoAEDNoite {

    public static void main(String[] args) {
//        System.out.println("Hello World");
//        
//        Scanner sc = new Scanner(System.in);
//        
//        int n1, n2;
//        
//        System.out.println("Digite dois numeros: ");
//        n1 = sc.nextInt();
//        n2 = sc.nextInt();
//        
//        if(n1 > n2)
//            System.out.println("O numero " + n1 + "eh o maior");
//        else
//            System.out.println("O numero " + n2 + "eh o maior");
//        
//        
//        sc.close();
        
        Cachorro c1 = new Cachorro("Rex", "Pitbull", 10, 45.6, 'G');
        Cachorro c2 = new Cachorro("Coragem, o Cao Covarde", "Vira Lata", 5, 7.9, 'M');
        Cachorro c3 = new Cachorro("Trovao", "Pinscher", 8, 2.7, 'P');
        
        System.out.println("Exibindo cao c1:");
        c1.exibe();
        c1.late(5);
        
        System.out.println("\nExibindo cao c2:");
        c2.exibe();
        c2.late(3);
        
        c1.setIdade(8);
         
        if (c1.getPeso()> c2.getPeso())
            System.out.println("O cao " + c1.getNome()+" eh mais pesado");
        else if (c2.getPeso()> c3.getPeso()) 
            System.out.println("O cao " + c2.getNome()+ "eh mais pesado ");
        else
            System.out.println("o cao" + c3.getNome() + "eh mais pesado");

    }
    
}
